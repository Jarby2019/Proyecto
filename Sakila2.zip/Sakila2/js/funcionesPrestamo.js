var dt;

function prestamo(){
    $("#contenido").on("click","button#actualizar",function(){
         var datos=$("#fprestamo").serialize();
         $.ajax({
            type:"get",
            url:"./php/prestamo/controladorPrestamo.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Actualizado!',
                    'Se actualizaron los datos correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado Prestamo");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#prestamo").removeClass("hide");
                $("#prestamo").addClass("show");
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    })

    $("#contenido").on("click","a.borrar",function(){
        //Recupera datos del formulario
        var codigo = $(this).data("codigo");

        swal({
              title: '¿Está seguro?',
              text: "¿Realmente desea borrar el prestamo con codigo : " + codigo + " ?",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Si, Borrarlo!'
        }).then((decision) => {
                if (decision.value) {

                    var request = $.ajax({
                        method: "get",
                        url: "./php/prestamo/controladorPrestamo.php",
                        data: {codigo: codigo, accion:'borrar'},
                        dataType: "json"
                    })

                    request.done(function( resultado ) {
                        if(resultado.respuesta == 'correcto'){
                            swal(
                                'Borrado!',
                                'El prestamo con codigo : ' + codigo + ' fue borrado',
                                'success'
                            )     
                            dt.ajax.reload();                            
                        } else {
                            swal({
                              type: 'error',
                              title: 'Oops...',
                              text: 'Something went wrong!'                         
                            })
                        }
                    });
                     
                    request.fail(function( jqXHR, textStatus ) {
                        swal({
                          type: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!' + textStatus                          
                        })
                    });
                }
        })

    });

    $("#contenido").on("click","button.btncerrar2",function(){
        $("#titulo").html("Listado Prestamo");
        $("#nuevo-editar").html("");
        $("#nuevo-editar").removeClass("show");
        $("#nuevo-editar").addClass("hide");
        $("#prestamo").removeClass("hide");
        $("#prestamo").addClass("show");

    })

    $("#contenido").on("click","button.btncerrar",function(){
        $("#contenedor").removeClass("show");
        $("#contenedor").addClass("hide");
        $("#contenido").html('');
    })

    $("#contenido").on("click","button#nuevo",function(){
        $("#titulo").html("Nuevo Prestamo");
        var rol;
        $("#nuevo-editar" ).load("./php/prestamo/nuevoPrestamo.php"); 
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#prestamo").removeClass("show");
        $("#prestamo").addClass("hide");
        $.ajax({
            type:"get",
            url:"./php/cliente/controladorCliente.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {   
             //console.log(resultado.data)           
             $("#customer_id option").remove()       
             $("#customer_id").append("<option selecte value=''>Seleccione una cliente</option>")
             $.each(resultado.data, function (index, value) { 
               $("#customer_id").append("<option value='" + value.customer_id + "'>" + value.cliente + "</option>")
             });
          });  
          $.ajax({
            type:"get",
            url:"./php/empleado/controladorEmpleado.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {   
             //console.log(resultado.data)           
             $("#staff_id option").remove()       
             $("#staff_id").append("<option selecte value=''>Seleccione un Empleado</option>")
             $.each(resultado.data, function (index, value) { 
               $("#staff_id").append("<option value='" + value.staff_id + "'>" + value.empleado + "</option>")
             });
          }); 
          $.ajax({
            type:"get",
            url:"./php/inventario/controladorInventario.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {   
             //console.log(resultado.data)           
             $("#inventory_id option").remove()       
             $("#inventory_id").append("<option selecte value=''>Seleccione un Inventariado</option>")
             $.each(resultado.data, function (index, value) { 
               $("#inventory_id").append("<option value='" + value.inventory_id + "'>" + value.title + "</option>")
             });
          }); 
    })

    $("#contenido").on("click","button#grabar",function(){
        /*var comu_codi = $("#comu_codi").attr("value");
        var comu_nomb = $("#comu_nomb").attr("value");
        var muni_codi = $("#muni_codi").attr("value");
        var datos = "comu_codi="+comu_codi+"&comu_nomb="+comu_nomb+"&muni_codi="+muni_codi;*/
      
      var datos=$("#fprestamo").serialize();
       $.ajax({
            type:"get",
            url:"./php/prestamo/controladorPrestamo.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Grabado!!',
                    'El registro se grabó correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado prestamo");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#prestamo").removeClass("hide");
                $("#prestamo").addClass("show");
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    });


    $("#contenido").on("click","a.editar",function(){
       $("#titulo").html("Editar prestamo");
       //Recupera datos del fromulario
       var codigo = $(this).data("codigo");
       var cliente;
       var empleado;
       var inventario;
        $("#nuevo-editar").load("./php/prestamo/editarPrestamo.php");
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#prestamo").removeClass("show");
        $("#prestamo").addClass("hide");
       $.ajax({
           type:"get",
           url:"./php/prestamo/controladorPrestamo.php",
           data: {codigo: codigo, accion:'consultar'},
           dataType:"json"
           }).done(function( prestamo ) {        
                if(prestamo.respuesta === "no existe"){
                    swal({
                      type: 'error',
                      title: 'Oops...',
                      text: 'El prestamo no existe!!!!!'                         
                    })
                } else {
                    $("#rental_id").val(prestamo.codigo);                   
                    $("#rental_date").val(prestamo.fecha_prestamo);
                    inventario = prestamo.inventario; 
                    cliente = prestamo.cliente; 
                    $("#return_date").val(prestamo.fecha_retorno);                   
                    empleado = prestamo.empleado;     
                                  
                }
           });  
           
           $.ajax({
            type:"get",
            url:"./php/inventario/controladorInventario.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {                     
             $("#inventory_id option").remove();
             $.each(resultado.data, function (index, value) { 
               
               if(inventario === value.inventory_id){
                 $("#inventory_id").append("<option selected value='" + value.inventory_id + "'>" + value.title + "</option>")
               }else {
                 $("#inventory_id").append("<option value='" + value.inventory_id + "'>" + value.title + "</option>")
               }
             });
            });

            $.ajax({
              type:"get",
              url:"./php/cliente/controladorCliente.php",
              data: {accion:'listar'},
              dataType:"json"
            }).done(function( resultado ) {                     
               $("#customer_id option").remove();
               $.each(resultado.data, function (index, value) { 
                 
                 if(cliente === value.customer_id){
                   $("#customer_id").append("<option selected value='" + value.customer_id + "'>" + value.cliente + "</option>")
                 }else {
                   $("#customer_id").append("<option value='" + value.customer_id + "'>" + value.cliente + "</option>")
                 }
               });
              });

              $.ajax({
                type:"get",
                url:"./php/empleado/controladorEmpleado.php",
                data: {accion:'listar'},
                dataType:"json"
              }).done(function( resultado ) {                     
                 $("#staff_id option").remove();
                 $.each(resultado.data, function (index, value) { 
                   
                   if(empleado=== value.staff_id){
                     $("#staff_id").append("<option selected value='" + value.staff_id + "'>" + value.empleado + "</option>")
                   }else {
                     $("#staff_id").append("<option value='" + value.staff_id + "'>" + value.empleado + "</option>")
                   }
                 });
                });

       })
}


$(document).ready(() => {
  $("#contenido").off("click", "a.editar");
  $("#contenido").off("click", "button#actualizar");
  $("#contenido").off("click","a.borrar");
  $("#contenido").off("click","button#nuevo");
  $("#contenido").off("click","button#grabar");
  $("#titulo").html("Listado de Prestamos");
  dt = $("#tabla").DataTable({
        "ajax": "php/prestamo/controladorPrestamo.php?accion=listar",
        "columns": [
          { "data": "rental_id"},
          { "data": "rental_date" },
          { "data": "inventory_id" },
          { "data": "cliente" },
          { "data": "return_date" },
          { "data": "empleado" },
          { "data": "last_update" },
            
            { "data": "rental_id",
                render: function (data) {
                          return '<a href="#" data-codigo="'+ data + 
                                 '" class="btn btn-danger btn-sm borrar"> <i class="fa fa-trash"></i></a>' 
                }
            },
            { "data": "rental_id",
                render: function (data) {
                          return '<a href="#" data-codigo="'+ data + 
                                 '" class="btn btn-primary btn-sm editar"> <i class="fa fa-edit"></i></a>';
                }
            }
        ]
  });
  prestamo();
});