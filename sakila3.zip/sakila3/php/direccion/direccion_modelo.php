<?php
	require_once('../modeloAbstractoDB.php');
	class Direccion extends ModeloAbstractoDB {
		private $address_id;
		private $address;
		private $district;
		private $city_id;
		private $postal_code;
		private $phone;
		private $last_update;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getaddress_id(){
			return $this->address_id;
		}

		public function getaddress(){
			return $this->address;
		}
		
		public function getdistrict(){
			return $this->district;
		} 

		public function getcity_id(){
			return $this->city_id;
		}  

		public function getpostal_code(){
			return $this->postal_code;
		}   
		
		public function getphone(){
			return $this->phone;
		}  

		public function getlast_update(){
			return $this->last_update;
		}  

		public function consultar($address_id='') {
			if($address_id != ''):
				$this->query = "
				SELECT address_id, address, district, city_id, postal_code, phone, last_update 
				FROM address 
				WHERE address_id = '$address_id'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT ad.address_id, ad.address, ad.district, c.city_id, c.city, ad.postal_code, ad.phone, ad.last_update 
				FROM address as ad INNER JOIN city as c 
				ON (ad.city_id = c.city_id) 
				ORDER BY address_id
				";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('address_id', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO address
					(address, district, city_id, postal_code , phone)
					VALUES
					($address', '$district', '$city_id', '$postal_code', '$phone')
					";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE address
			SET address='$address',
			district='$district',
			city_id='$city_id',
			postal_code='$postal_code',
			phone='$phone'
			WHERE address_id = '$address_id'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($address_id='') {
			$this->query = "
			DELETE FROM address
			WHERE address_id = '$address_id'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>