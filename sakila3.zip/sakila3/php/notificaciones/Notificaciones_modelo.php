<?php
	require_once('../modeloAbstractoDB.php');
	class Notificaciones extends ModeloAbstractoDB {
		private $noti_codi;
		private $noti_desc;
		private $staff_id;
		private $fecha;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getnoti_codi(){
			return $this->noti_codi;
		}

		public function getnoti_desc(){
			return $this->noti_desc;
		}
		
		public function getstaff_id(){
			return $this->staff_id;
		} 

		public function getfecha(){
			return $this->fecha;
		}  

		public function consultar($noti_codi='') {
			if($noti_codi != ''):
				$this->query = "
				SELECT noti_codi, noti_desc, staff_id, fecha
				FROM notificaciones
				WHERE noti_codi = '$noti_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT noti_codi, noti_desc, CONCAT(c.first_name, ' ', c.last_name) as usuario, fecha
			FROM notificaciones as f 
				inner join staff as c 
				ON f.staff_id = c.staff_id
				";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		
		public function nuevo($datos=array()) {
			if(array_key_exists('noti_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO notificaciones
					(noti_codi, staff_id, noti_desc,  fecha)
					VALUES
					(NULL, '$staff_id', '$noti_desc',  '$fecha')
					";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE notificaciones
			SET staff_id='$staff_id',
			noti_desc='$noti_desc',
			fecha='$fecha'
			WHERE noti_codi = '$noti_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($noti_codi='') {
			$this->query = "
			DELETE FROM notificaciones
			WHERE noti_codi = '$noti_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>