<?php
 
require_once 'Notificaciones_modelo.php';
$datos = $_GET;

switch ($_GET['accion']){
    case 'editar':
        $notificaciones = new Notificaciones();
		$resultado = $notificaciones->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $notificaciones = new Notificaciones();
		$resultado = $notificaciones->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$notificaciones = new Notificaciones();
		$resultado = $notificaciones->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $notificaciones = new Notificaciones();
        $notificaciones->consultar($datos['codigo']);

        if($notificaciones->getnoti_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $notificaciones->getnoti_codi(),
                'usuario' =>$notificaciones->getstaff_id(),
                'notificacion' => $notificaciones->getnoti_desc(),
                'fecha' =>$notificaciones->getfecha(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $notificaciones = new Notificaciones();
        $listado = $notificaciones->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
