<?php
 
require_once 'empleado_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $empleado = new Empleado();
        $resultado = $empleado->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $empleado = new Empleado();
        $resultado = $empleado->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $empleado = new Empleado();
        $resultado = $empleado->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $empleado = new Empleado();
        $empleado->consultar($datos['codigo']);

        if($empleado->getStaff_id() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $empleado->getStaff_id(),
                'nombre' => $empleado->getFirst_name(),
                'apellido' => $empleado->getLast_name(),
                'direccion' => $empleado->getAddress_id(),
                'email' => $empleado->getEmail(),
                'rol' => $empleado->getRol_id(),
                'usuario' => $empleado->getUsername(),
                'contrasena' => $empleado->getPassword(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $empleado = new Empleado();
        $listado = $empleado->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
