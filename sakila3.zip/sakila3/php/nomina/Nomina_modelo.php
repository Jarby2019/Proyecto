<?php
	require_once('../modeloAbstractoDB.php');
	class Nomina extends ModeloAbstractoDB {
		private $pago_codi;
		private $pago_cant;
		private $emple_codi;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getpago_codi(){
			return $this->pago_codi;
		}

		public function getpago_cant(){
			return $this->pago_cant;
		}
		
		public function getemple_codi(){
			return $this->emple_codi;
		}                

		public function consultar($pago_codi='') {
			if($pago_codi != ''):
				$this->query = "
				SELECT pago_codi, pago_cant, emple_codi
				FROM tb_nomina
				WHERE pago_codi = '$pago_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT pago_codi, pago_cant, p.emple_nomb
			FROM tb_nomina as m inner join tb_empleados as p
			ON (m.emple_codi = p.emple_codi) ORDER BY m.pago_codi
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		public function listanomina() {
			$this->query = "
			SELECT pago_codi, pago_cant
			FROM tb_nomina as d order by pago_cant
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('pago_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_nomina
				(pago_codi, pago_cant, emple_codi)
				VALUES
				('$pago_codi', '$pago_cant', '$emple_codi')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_nomina
			SET pago_cant='$pago_cant',
			emple_codi='$emple_codi'
			WHERE pago_codi = '$pago_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($pago_codi='') {
			$this->query = "
			DELETE FROM tb_nomina
			WHERE pago_codi = '$pago_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>