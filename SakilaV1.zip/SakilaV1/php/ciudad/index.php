<div id="nuevo-editar" class="hide">
		<!-- div para cargar el formulario para un nuevo departamento o editar un departamento -->
</div>

<div id="ciudades">
<div class="box-header">
    <i class="ion ion-clipboard"></i>
     <!-- tools box -->
    <div class="pull-right box-tools">
    	<button class="btn btn-primary btn-sm" id="nuevo"  data-toggle="tooltip" title="Nuevo Ciudad"><i class="fa fa-plus" aria-hidden="true"></i></button> 
    	<button class="btn btn-primary btn-sm btncerrar"  data-toggle="tooltip" title="Ocultar"><i class="fa fa-times"></i></button>
    	<td width="100"><a target="_blank" href="registros/vistas/ciudades.php" class="btn btn-primary">PDF</a></td>

    </div><!-- /. tools -->
                  
</div><!-- /.box-header -->

<div class="box-body">

	<table id="tabla" class="table table-striped table-bordered table-hover" cellspacing="0" width="100%">
		<thead>
			<tr>
				<th>Codigo</th>
				<th>Nombre</th>
				<th>Pais</th>
				<th>Ultima Actualizacion</th>
				<th>&nbsp;</th>
				<th>&nbsp;</th>
			</tr>
		</thead>
		<tbody>
		
		</tbody>

	</table>

</div><!-- /.box-body -->  
<script src="js/funcionesCiudades.js"></script>
</div>