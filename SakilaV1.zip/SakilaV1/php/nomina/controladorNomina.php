<?php
 
require_once 'Nomina_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $nomina = new Nomina();
		$resultado = $nomina->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $nomina = new Nomina();
		$resultado = $nomina->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$nomina = new Nomina();
		$resultado = $nomina->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $nomina = new Nomina();
        $nomina->consultar($datos['codigo']);

        if($nomina->getpago_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $nomina->getpago_codi(),
                'nomina' => $nomina->getpago_cant(),
                'empleados' =>$nomina->getemple_codi(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $nomina = new Nomina();
        $listado = $nomina->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
