<?php
require('../fpdf/fpdf.php');
require('../php/conexion.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 10);
$pdf->Image('../recursos/logo.png' , 10 ,8, 15 , 20,'png');
$pdf->Cell(18, 10, '', 0);
$pdf->Cell(150, 10, 'Listado de Clientes"', 0);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(50, 10, 'Fecha: '.date('d-m-Y').'', 0);
$pdf->Ln(15);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(70, 8, '', 0);
$pdf->Cell(100, 8, 'LISTADO DE CLIENTES', 0);
$pdf->Ln(23);
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(10, 8, 'ID', 0);
$pdf->Cell(10, 8, 'Tienda', 0);
$pdf->Cell(20, 8, 'Nombre', 0);
$pdf->Cell(20, 8, 'Apellido', 0);
$pdf->Cell(55, 8, 'Correo', 0);
$pdf->Cell(20, 8, 'Cod. Dir', 0);
$pdf->Cell(30, 8, 'Creado', 0);
$pdf->Cell(30, 8, 'Actualizado', 0);
$pdf->Ln(8);
$pdf->SetFont('Arial', '', 8);
//CONSULTA
$productos = mysql_query("SELECT customer_id, store_id, first_name, last_name, email, address_id, create_date, last_update 
				FROM customer
			 order by customer_id");

while($productos2 = mysql_fetch_array($productos)){
	$pdf->Cell(10, 8, $productos2['customer_id'], 0);
	$pdf->Cell(10, 8,$productos2['store_id'], 0);
	$pdf->Cell(20, 8, $productos2['first_name'] , 0);
	$pdf->Cell(20, 8,$productos2['last_name'], 0);
	$pdf->Cell(60, 8, $productos2['email'] , 0);
	$pdf->Cell(15, 8, $productos2['address_id'] , 0);
	$pdf->Cell(30, 8,$productos2['create_date'], 0);
	$pdf->Cell(30, 8, $productos2['last_update'] , 0);
	$pdf->Ln(8);
}
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(114,8,'',0);
$pdf->Output();
?>