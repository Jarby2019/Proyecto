
<!DOCTYPE html>
<html lang="en">
<head>
<?php include_once ("./Funciones/sessiones.php"); ?>
  <title>SAKILA</title>
  <meta charset="utf-8">
  <link rel="icon" href="Recursos/img/icon.ico">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <link rel ="stylesheet" href="css/estilo.css"/>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
  
</head>
<style>
.jumbotron {
    background-color: 	#87CEEB;
    color: #fff;
  
}

</style>
<body>
<div class="jumbotron jumbotron-billboard">
          <div class="img"></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                    <center><H1 style=color:RED>MULTICINE SAKILA!!</H1></center>
                    <?php

                    echo '<h2 align=center><font color="black">'.$_SESSION["usuario"].'</font></h2>';

                      ?>
            <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400" style=color:black></i>
                  <center><button class="btn btn-danger">Cerrar session</button></center>
                  <br><br><br><br>
                  <br><br><br><br>
                </a>
              </div>
        
              </div>
            </div>
        </div>

    <div class="container">
        <div class="panel-group"><div class="panel panel-primary">
            <div class="panel-heading">Tablas de Gestion</div>
            <div class="panel-body">
                
                <div class="form-group" id="opciones">        
                    <div class="col-sm-10">

                    <?php

                    if ($_SESSION["rol"]==0) {

                      ?>
                      <a class="btn btn-danger" href="php/usuario/index.php" role="button" style=color:black;>Usuarios</a>
                      <a class="btn btn-primary" href="php/actor/index.php" role="button" style=color:black; >Actores</a>
                      <a class="btn btn-primary" href="php/tienda/index.php" role="button" style=color:black;>Tienda</a>
                      <a class="btn btn-primary" href="php/rol/index.php" role="button" style=color:black;>Roles</a>
                      <a class="btn btn-primary" href="php/empleado/index.php" role="button" style=color:black;>Empleado</a>
                      <a class="btn btn-primary" href="php/categoria/index.php" role="button" style=color:black;>Categoria</a>
                      <a class="btn btn-primary" href="php/pelicula/index.php" role="button" style=color:black;>Pelicula</a>
                      <a class="btn btn-primary" href="php/cliente/index.php" role="button" style=color:black;>Cliente</a>
                      <a class="btn btn-primary" href="php/direccion/index.php" role="button" style=color:black;>Direccion</a>
                      
                      <a class="btn btn-primary" href="php/inventario/index.php" role="button" style=color:black;>Inventario</a>
                      <a class="btn btn-primary" href="php/idioma/index.php" role="button" style=color:black;>Idioma</a>
                      <a class="btn btn-primary" href="php/prestamo/index.php" role="button" style=color:black;>Prestamo</a>
                      <a class="btn btn-primary" href="php/pago/index.php" role="button" style=color:black;>Pagos</a>
                      <a class="btn btn-primary" href="php/pais/index.php" role="button" style=color:black;>Paises</a> 
                      <a class="btn btn-primary" href="php/ciudad/index.php" role="button" style=color:black;>Ciudades</a>
                
                
                
              
                       
                      <?php
            } else
             if ($_SESSION["rol"]==1) {
              ?>
                <a class="btn btn-primary" href="php/empleado/index.php" role="button" style=color:black;>Empleado</a>
                <a class="btn btn-primary" href="php/inventario/index.php" role="button" style=color:black;>Inventario</a>
                <a class="btn btn-primary" href="php/idioma/index.php" role="button" style=color:black;>Idioma</a>
                <a class="btn btn-primary" href="php/prestamo/index.php" role="button" style=color:black;>Prestamo</a>
                <a class="btn btn-primary" href="php/pago/index.php" role="button" style=color:black;>Pagos</a>
                <a class="btn btn-primary" href="php/notificaciones/index.php" role="button" style=color:black;>Notificaciones</a>
                <?php

            }else
            if ($_SESSION["rol"]==2) {
              ?>
              <a class="btn btn-primary" href="php/cliente/index.php" role="button" style=color:black;>Cliente</a>
              <a class="btn btn-primary" href="php/pelicula/index.php" role="button" style=color:black;>Pelicula</a>
              <a class="btn btn-primary" href="php/pago/index.php" role="button" style=color:black;>Pagos</a>
              <a class="btn btn-primary" href="php/prestamo/index.php" role="button" style=color:black;>Prestamo</a>
              <a class="btn btn-primary" href="php/notificaciones/indexx.php" role="button" style=color:black;>Notificaciones</a>
              <?php
              }else
              
              if ($_SESSION["rol"]==3) {
                ?>
              <a class="btn btn-primary" href="php/categoria/index.php" role="button" style=color:black;>Categoria</a>
              <a class="btn btn-primary" href="php/pelicula/index.php" role="button" style=color:black;>Pelicula</a>
              <a class="btn btn-primary" href="php/actor/index.php" role="button" style=color:black; >Actores</a>
              <a class="btn btn-primary" href="php/notificaciones/indexx.php" role="button" style=color:black;>Notificaciones</a>
              <?php
              }
              ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="panel-group hide" id="contenedor"><div class="panel panel-primary">
            <div class="panel-heading" id="titulo"></div>
            <div class="panel-body">
                
                <div class="form-group" id="contenido">        
                    
                </div>
            </div>
        </div>
    </div>
    <input type="hidden" id="pagina" value="index" name="editar"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <!-- Librearía para las funcionalidades de la tabla -->
    <script src="https://cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.11/js/dataTables.bootstrap.min.js"></script>
    <!-- Librería para las alertas -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.28.2/sweetalert2.all.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>

    <!-- Funciones de Lógica de negocio -->
    <script src="js/funcionesJquery.js"></script>
    <!-- Funciones de Lógica de neogcio -->
    <script>
        $(document).ready(Inicio);
    </script>
</body>

<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">¿Desea Salir?</div>
        <div class="modal-footer">
          <button class="btn btn-primary" type="button" data-dismiss="modal">NO</button>
          <a class="btn btn-danger" href="index.php?cerrar_session=true">SI</a>
        </div>
      </div>
    </div>
  </div>
</html>