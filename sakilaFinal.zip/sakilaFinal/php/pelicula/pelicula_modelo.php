<?php
	require_once('../modeloAbstractoDB.php');
	class Pelicula extends ModeloAbstractoDB {
		public $film_id; 	
        public $title;
        public $picture;
        public $description;
        public $release_year;
        public $language_id;
        public $rental_duration;
        public $rental_rate;
        public $length;
        public $replacement_cost;
        public $rating;
        public $special_features;
        public $last_update;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getFilm_id(){
			return $this->film_id;
		}

		public function getTitle(){
			return $this->title;
        }
        
        public function getPicture(){
			return $this->picture;
        }
        
        public function getDescription(){
			return $this->description;
        }
        
        public function getRelease_year(){
			return $this->release_year;
        }

        public function getLanguage_id(){
			return $this->language_id;
        }

        public function getRental_duration(){
			return $this->rental_duration;
        }

        public function getRental_rate(){
			return $this->rental_rate;
        }

        public function getLength(){
			return $this->length;
        }

        public function getReplacement_cost(){
			return $this->replacement_cost;
        }

        public function getRating(){
			return $this->rating;
		}
        
        public function getSpecial_features(){
			return $this->special_features;
        }

        public function getLast_update(){
			return $this->last_update;
		}
		
          

		public function consultar($film_id='') {
			if($film_id != ''):
				$this->query = "
				SELECT film_id,title,picture,description,release_year,language_id,rental_duration,rental_rate,length,replacement_cost,rating,special_features,last_update
				FROM film
				WHERE film_id = '$film_id' and estado != 1 order by film_id
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT film_id,title,
			IFNULL((SELECT GROUP_CONCAT(y.name separator ', ')
				FROM film_category as c
				INNER JOIN category as y ON (c.category_id=y.category_id)
				WHERE c.film_id=f.film_id),'Sin asignar') as categoria,
					IFNULL((SELECT GROUP_CONCAT(DISTINCT store_id separator ', ')
						FROM inventory as i
						WHERE i.film_id=f.film_id),'Sin asignar') as tienda,
						description,release_year,l.name as idioma,rental_rate,length,rating
							FROM film as f
							INNER JOIN language as l
							ON (f.language_id = l.language_id)
							WHERE f.estado != 1
							ORDER BY film_id
			";
			
			$this->obtener_resultados_query();
			return $this->rows;
		}

		
		public function nuevo($datos=array()) {
			if(array_key_exists('film_id', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO film
				(title,description,release_year,language_id,rental_duration,rental_rate,length,replacement_cost,rating,special_features)
				VALUES
				('$title','$description','$release_year','$language_id','$rental_duration','$rental_rate','$length','$replacement_cost','$rating','$special_features')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE film
            SET title='$title',
            description='$description',
			release_year='$release_year',
			language_id='$language_id',
            rental_duration='$rental_duration',
            rental_rate='$rental_rate',
            length='$length',
            replacement_cost='$replacement_cost',
            rating='$rating',
            special_features='$special_features'
			WHERE film_id = '$film_id'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($film_id='') {
			$this->query = "
			DELETE FROM film
			WHERE film_id = '$film_id'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>