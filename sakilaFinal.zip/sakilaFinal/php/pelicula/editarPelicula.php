   <div id="seccion-pelicula">
    <div class="box-header">
    	<i class="fa fa-building" aria-hidden="true">Gestion de Pelicula</i>
        
        <!-- tools box -->
        <div class="pull-right box-tools">
        	<button class="btn btn-info btn-sm btncerrar2" data-toggle="tooltip" title="Cerrar"><i class="fa fa-times"></i></button>
        </div><!-- /. tools -->
    </div>
    <div class="box-body">

		<div align ="center">
				<div id="actual"> 
				</div>
		</div>

        <div class="panel-group"><div class="panel panel-primary">
            <div class="panel-heading">Datos</div>
            <div class="panel-body">
    
                <form class="form-horizontal" role="form"  id="fpelicula">


 					<div class="form-group">
                        <label class="control-label col-sm-2" for="film_id">Codigo:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="film_id" name="film_id" placeholder="Ingrese Codigo"
                            value = "" readonly="true">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="title">Nombre:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="title" name="title" placeholder="Ingrese Nombre Pelicula"
                            value = "">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="description">Descripcion:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="description" name="description" placeholder="Ingrese  Descripcion"
                            value = "">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="release_year">Estreno:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="release_year" name="release_year" placeholder="Ingrese Fecha Estreno"
                            value = "">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="language_id">Idioma:</label>
                        <div class="col-sm-10">
                            <select class="form-control" id="language_id" name="language_id">
                            
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="rental_duration">Tiempo Renta:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="rental_duration" name="rental_duration" placeholder="Ingrese Tiempo Renta"
                            value = "">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="rental_rate">Valor Alquiler:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="rental_rate" name="rental_rate" placeholder="Ingrese Precio Alquiler"
                            value = "">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="length">Duracion:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="length" name="length" placeholder="Ingrese Duracion"
                            value = "">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="replacement_cost">Costo Reemplazo:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="replacement_cost" name="replacement_cost" placeholder="Ingrese Costo"
                            value = "">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="rating">Clasificacion:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="rating" name="rating" placeholder="Ingrese Clasificacion"
                            value = "">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="special_features">Caracteristicas Especiales:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="special_features" name="special_features" placeholder="Ingrese Caracteristicas"
                            value = "">
                        </div>
                    </div>
					

					 <div class="form-group">        
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="button" id="actualizar" data-toggle="tooltip" title="Actualizar Pelicula" class="btn btn-primary">Actualizar</button>
                            <button type="button" id="cancelar" data-toggle="tooltip" title="Cancelar Edición" class="btn btn-primary btncerrar2"> Cancelar </button>
                        </div>

                    </div>                    

					<input type="hidden" id="editar" value="editar" name="accion"/>
			</fieldset>

		</form>
	</div>
    <input type="hidden" id="pagina" value="editar" name="editar"/>
</div>