<?php
 
require_once 'usuario_modelos.php';

$username = htmlspecialchars(trim("$_POST[username]"));
$password = htmlspecialchars(trim("$_POST[password]"));
$datos = array("username"=>$username, "password"=>$password);
$actualizacion = $_POST;
// var_dump($datos);
// var_dump($actualizacion);
switch ($_POST['accion']){
   
    case 'login':
        $usuario = new Usuario();
        $usuario->consultar($datos);
        if($usuario->getStaff_id() == null) {
           
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            // echo 'console.log('. $usuario->getPassword() .')';
            // echo 'console.log('. $datos['password'] .')';
            if(password_verify($datos['password'],$usuario->getPassword())){
                // if ($usuario->getRol_id() == 1 || $usuario->getRol_id() == 0 || $usuario->getRol_id() == 2) {
                    session_start();
                    $_SESSION['usuario'] = $usuario->getUsername();
                    $_SESSION['first_name'] = $usuario->getFirst_name();
                    $_SESSION['rol']= $usuario->getRol_id();
                    $_SESSION['id']= $usuario->getStaff_id();
                    $respuesta = array(
                        'respuesta' =>'existe'
                    );
                    // echo 'console.log('. $usuario->getPicture($usuario->getStaff_id()) .')';
                    // $respuesta = array(
                    //     'respuesta' =>'empleado'
                    // );
                // } else {
                //     $respuesta = array(
                //         'respuesta' =>'usuario'
                //     );
                // }
            } else {
                $respuesta = array(
                    'respuesta' => 'no existe'
                );
            }
            
        }
        echo json_encode($respuesta);
        break;
    break;


    case 'editar':
        $usuario = new Usuario();
        $resultado = $usuario->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $usuario = new Usuario();
        $resultado = $usuario->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $usuario = new Usuario();
        $resultado = $usuario->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $usuario = new Usuario();
        $usuario->consultar($datos['codigo']);

        if($usuario->getStaff_id() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $usuario->getStaff_id(),
                'nombre' => $usuario->getFirst_name(),
                'apellido' => $usuario->getLast_name(),
                'direccion' => $usuario->getAddress_id(),
                'email' => $usuario->getEmail(),
                'rol' => $usuario->getRol_id(),
                'usuario' => $usuario->getUsername(),
                'contrasena' => $usuario->getPassword(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $usuario = new Usuario();
        $listado = $usuario->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
