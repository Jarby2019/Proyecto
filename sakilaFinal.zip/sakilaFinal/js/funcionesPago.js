var dt;

function pago(){
    $("#contenido").on("click","button#actualizar",function(){
         var datos=$("#fpago").serialize();
         $.ajax({
            type:"get",
            url:"./php/pago/controladorPago.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Actualizado!',
                    'Se actualizaron los datos correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado Pagos");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#pago").removeClass("hide");
                $("#pago").addClass("show");
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    })

    $("#contenido").on("click","a.borrar",function(){
        //Recupera datos del formulario
        var codigo = $(this).data("codigo");

        swal({
              title: '¿Está seguro?',
              text: "¿Realmente desea borrar el pago con codigo : " + codigo + " ?",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Si, Borrarlo!'
        }).then((decision) => {
                if (decision.value) {

                    var request = $.ajax({
                        method: "get",
                        url: "./php/pago/controladorPago.php",
                        data: {codigo: codigo, accion:'borrar'},
                        dataType: "json"
                    })

                    request.done(function( resultado ) {
                        if(resultado.respuesta == 'correcto'){
                            swal(
                                'Borrado!',
                                'El pago con codigo : ' + codigo + ' fue borrado',
                                'success'
                            )     
                            dt.ajax.reload();                            
                        } else {
                            swal({
                              type: 'error',
                              title: 'Oops...',
                              text: 'Something went wrong!'                         
                            })
                        }
                    });
                     
                    request.fail(function( jqXHR, textStatus ) {
                        swal({
                          type: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!' + textStatus                          
                        })
                    });
                }
        })

    });

    $("#contenido").on("click","button.btncerrar2",function(){
        $("#titulo").html("Listado pago");
        $("#nuevo-editar").html("");
        $("#nuevo-editar").removeClass("show");
        $("#nuevo-editar").addClass("hide");
        $("#pago").removeClass("hide");
        $("#pago").addClass("show");

    })

    $("#contenido").on("click","button.btncerrar",function(){
        $("#contenedor").removeClass("show");
        $("#contenedor").addClass("hide");
        $("#contenido").html('');
    })

    $("#contenido").on("click","button#nuevo",function(){
        $("#titulo").html("Nuevo pago");
        var rol;
        $("#nuevo-editar" ).load("./php/pago/nuevoPago.php"); 
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#pago").removeClass("show");
        $("#pago").addClass("hide");
        $.ajax({
            type:"get",
            url:"./php/cliente/controladorCliente.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {   
             //console.log(resultado.data)           
             $("#customer_id option").remove()       
             $("#customer_id").append("<option selecte value=''>Seleccione una Cliente</option>")
             $.each(resultado.data, function (index, value) { 
               $("#customer_id").append("<option value='" + value.customer_id + "'>" + value.cliente + "</option>")
             });
          });  
          $.ajax({
            type:"get",
            url:"./php/empleado/controladorEmpleado.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {   
             //console.log(resultado.data)           
             $("#staff_id option").remove()       
             $("#staff_id").append("<option selecte value=''>Seleccione un Empleado</option>")
             $.each(resultado.data, function (index, value) { 
               $("#staff_id").append("<option value='" + value.staff_id + "'>" + value.empleado + "</option>")
             });
          }); 
          $.ajax({
            type:"get",
            url:"./php/prestamo/controladorPrestamo.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {   
             //console.log(resultado.data)           
             $("#rental_id option").remove()       
             $("#rental_id").append("<option selecte value=''>Seleccione una Renta</option>")
             $.each(resultado.data, function (index, value) { 
               $("#rental_id").append("<option value='" + value.rental_id + "'>" + value.rental_id + "</option>")
             });
          }); 
    })

    $("#contenido").on("click","button#grabar",function(){
        /*var comu_codi = $("#comu_codi").attr("value");
        var comu_nomb = $("#comu_nomb").attr("value");
        var muni_codi = $("#muni_codi").attr("value");
        var datos = "comu_codi="+comu_codi+"&comu_nomb="+comu_nomb+"&muni_codi="+muni_codi;*/
      
      var datos=$("#fpago").serialize();
       $.ajax({
            type:"get",
            url:"./php/pago/controladorPago.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Grabado!!',
                    'El registro se grabó correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado pago");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#pago").removeClass("hide");
                $("#pago").addClass("show");
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    });


    $("#contenido").on("click","a.editar",function(){
       $("#titulo").html("Editar pago");
       //Recupera datos del fromulario
       var codigo = $(this).data("codigo");
       var cliente;
       var empleado;
       var renta;
        $("#nuevo-editar").load("./php/pago/editarPago.php");
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#pago").removeClass("show");
        $("#pago").addClass("hide");
       $.ajax({
           type:"get",
           url:"./php/pago/controladorPago.php",
           data: {codigo: codigo, accion:'consultar'},
           dataType:"json"
           }).done(function( pago ) {        
                if(pago.respuesta === "no existe"){
                    swal({
                      type: 'error',
                      title: 'Oops...',
                      text: 'El pago no existe!!!!!'                         
                    })
                } else {
                    $("#payment_id").val(pago.codigo);                   
                    cliente = pago.cliente; 
                    empleado = pago.empleado; 
                    renta = pago.prestamo; 
                    $("#amount").val(pago.precio);
                    $("#payment_date").val(pago.fecha_pago);                   
                }
           });  
           
           $.ajax({
            type:"get",
            url:"./php/cliente/controladorCliente.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {                     
             $("#customer_id option").remove();
             $.each(resultado.data, function (index, value) { 
               
               if(cliente === value.customer_id){
                 $("#customer_id").append("<option selected value='" + value.customer_id + "'>" + value.cliente + "</option>")
               }else {
                 $("#customer_id").append("<option value='" + value.customer_id + "'>" + value.cliente + "</option>")
               }
             });
            });

            $.ajax({
              type:"get",
              url:"./php/empleado/controladorEmpleado.php",
              data: {accion:'listar'},
              dataType:"json"
            }).done(function( resultado ) {                     
               $("#staff_id option").remove();
               $.each(resultado.data, function (index, value) { 
                 
                 if(empleado === value.staff_id){
                   $("#staff_id").append("<option selected value='" + value.staff_id + "'>" + value.empleado + "</option>")
                 }else {
                   $("#staff_id").append("<option value='" + value.staff_id + "'>" + value.empleado + "</option>")
                 }
               });
              });

              $.ajax({
                type:"get",
                url:"./php/prestamo/controladorPrestamo.php",
                data: {accion:'listar'},
                dataType:"json"
              }).done(function( resultado ) {                     
                 $("#rental_id option").remove();
                 $.each(resultado.data, function (index, value) { 
                   
                   if(renta === value.rental_id){
                     $("#rental_id").append("<option selected value='" + value.rental_id + "'>" + value.rental_id + "</option>")
                   }else {
                     $("#rental_id").append("<option value='" + value.rental_id + "'>" + value.rental_id + "</option>")
                   }
                 });
                });

       })
}


$(document).ready(() => {
  $("#contenido").off("click", "a.editar");
  $("#contenido").off("click", "button#actualizar");
  $("#contenido").off("click","a.borrar");
  $("#contenido").off("click","button#nuevo");
  $("#contenido").off("click","button#grabar");
  $("#titulo").html("Listado de Pagos");
  dt = $("#tabla").DataTable({
        "ajax": "php/pago/controladorPago.php?accion=listar",
        "columns": [
          { "data": "payment_id"},
          { "data": "cliente" },
          { "data": "empleado" },
          { "data": "rental_id" },
          { "data": "amount" },
          { "data": "payment_date" },
          { "data": "last_update" },
            
            { "data": "payment_id",
                render: function (data) {
                          return '<a href="#" data-codigo="'+ data + 
                                 '" class="btn btn-danger btn-sm borrar"> <i class="fa fa-trash"></i></a>' 
                }
            },
            { "data": "payment_id",
                render: function (data) {
                          return '<a href="#" data-codigo="'+ data + 
                                 '" class="btn btn-primary btn-sm editar"> <i class="fa fa-edit"></i></a>';
                }
            }
        ]
  });
  pago();
});