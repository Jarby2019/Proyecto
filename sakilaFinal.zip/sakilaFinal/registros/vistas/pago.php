<?php
require('../fpdf/fpdf.php');
require('../php/conexion.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 10);
$pdf->Image('../recursos/logo.png' , 10 ,8, 15 , 20,'png');
$pdf->Cell(18, 10, '', 0);
$pdf->Cell(150, 10, 'Listado de Cobros"', 0);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(50, 10, 'Fecha: '.date('d-m-Y').'', 0);
$pdf->Ln(15);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(70, 8, '', 0);
$pdf->Cell(100, 8, 'LISTADO DE PAGOS', 0);
$pdf->Ln(23);
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(25, 8, 'Codigo', 0);
$pdf->Cell(25, 8, 'Nombre', 0);
$pdf->Cell(25, 8, 'Apellido', 0);
$pdf->Cell(15, 8, 'rental_id', 0);
$pdf->Cell(25, 8, 'Cod. Renta', 0);
$pdf->Cell(40, 8, 'Pagado', 0);
$pdf->Cell(40, 8, 'Ultima Actualizacion', 0);
$pdf->Ln(8);
$pdf->SetFont('Arial', '', 8);
//CONSULTA
$productos = mysql_query("SELECT payment_id,c.first_name, c.last_name,s.first_name,s.last_name ,rental_id,amount,payment_date,p.last_update
FROM payment as p
INNER JOIN customer as c ON (p.customer_id = c.customer_id)
INNER JOIN staff as s ON (p.staff_id = s.staff_id)
WHERE p.estado != 1 
ORDER BY payment_id
			");

while($productos2 = mysql_fetch_array($productos)){
	$pdf->Cell(25, 8, $productos2['payment_id'], 0);
	$pdf->Cell(25, 8,$productos2['first_name'], 0);
	$pdf->Cell(25, 8, $productos2['last_name'] , 0);
	$pdf->Cell(15, 8,$productos2['rental_id'], 0);
	$pdf->Cell(25, 8, $productos2['amount'] , 0);
	$pdf->Cell(40, 8,$productos2['payment_date'], 0);
	$pdf->Cell(40, 8, $productos2['last_update'] , 0);
	$pdf->Ln(8);
}
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(114,8,'',0);
$pdf->Output();
?>